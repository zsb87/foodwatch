plot(energy_acc_xyz,'g')
hold on
scatter(ans,energy_acc_xyz(ans),'b')