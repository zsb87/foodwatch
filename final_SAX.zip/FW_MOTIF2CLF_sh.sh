#!/bin/sh
python FW_MOTIF2CLF_inall.py 3 1 1.0 27.0
python FW_MOTIF2CLF_inall.py 4 1 1.0 27.0
python FW_MOTIF2CLF_inall.py 5 1 1.0 27.0
# for i in 'Eric'
# do
# 		echo ""
# 		echo ""
# 		echo "FW_MOTIF2CLF_inall: $i"
		
# 		python FW_MOTIF2CLF_inall.py $i
# done
